# Formula A+B+C 网页版（第一版）

## 功能
- 一次最多 20 场 = 40 支球队。
- 每场独立选择 Formula A / B / C。
- `/api/analyze`：联网研究并先预览结果。
- `/api/generate`：自动研究并生成每场一个 Excel，最后打包 ZIP。
- Formula C 已包含：比赛所属赛事积分榜优先、疲劳、未来密度、下3场、Intent、欧联/欧协联完整总榜与8/6场联赛阶段赛程接口。
- 三套规则在 `rules_config.json` 独立维护，防止 A/B/C 混用。

## 运行
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export OPENAI_API_KEY="你的API密钥"
# 可选：export OPENAI_MODEL="gpt-5.6"
uvicorn app:app --host 0.0.0.0 --port 8000
```
然后浏览器打开 `http://localhost:8000`。

## 为什么需要 OPENAI_API_KEY
你要求“只输入球队名就自动查询最新官方排名、赛程、伤停、赔率、欧战总榜等”。这些是实时联网数据。第一版使用 OpenAI Responses API 的 Web Search 作为统一研究层，再由固定规则引擎生成 Excel。当前 OpenAI 模型支持 Responses API 与 Web search。

## 部署
可部署到支持 Python/FastAPI 的云主机。不要把 API Key 写在前端；只放服务器环境变量。

## 第一版限制
1. Formula C 渲染器已经做成专用版式。
2. Formula A/B 目前后端规则已经分开，Excel renderer 先提供通用数据页；下一版应把你锁定的 Barcelona vs Racing Santander 公式A母版，以及完整公式B/UCL母版逐格复刻进去。
3. 实时研究结果仍需要来源核对；程序会保留 warnings 和 sources。
4. 对欧联/欧协联的完整8/6场赛程、总榜和实力等级，建议后续增加本地缓存表，以减少重复搜索成本。

## 文件结构
- `app.py`：后端、联网研究、Excel生成
- `rules_config.json`：Formula A/B/C 规则配置
- `static/index.html`：网页界面
- `requirements.txt`：依赖
